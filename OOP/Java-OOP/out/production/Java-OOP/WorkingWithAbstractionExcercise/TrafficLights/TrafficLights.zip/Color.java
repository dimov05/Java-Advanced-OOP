package WorkingWithAbstractionExcercise.TrafficLights;

public enum Color {
    RED,
    GREEN,
    YELLOW;

}
